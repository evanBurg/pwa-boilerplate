# pwa-boilerplate
Basic vanilla PWA boilerplate repository
